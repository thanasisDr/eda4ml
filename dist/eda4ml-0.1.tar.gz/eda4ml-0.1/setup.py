from setuptools import setup

setup(name='eda4ml',
      version='0.1',
      description='Methods for EDA in the ML process',
      packages=['eda4ml'],
      author='Athanasios Dritsas',
      author_email='thanasis.dritsas@gmail.com',
      zip_safe=False)